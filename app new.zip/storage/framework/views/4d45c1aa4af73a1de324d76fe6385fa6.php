
<script src="<?php echo e(asset('js/bootstrap.bundle.min.js')); ?>"></script>
<script src="<?php echo e(asset('js/jquery.min.js')); ?>"></script>
<?php /**PATH D:\Luthfi\Skripsi\Vira\App\vira_kartika_profil_matching\resources\views\includes\footer.blade.php ENDPATH**/ ?>