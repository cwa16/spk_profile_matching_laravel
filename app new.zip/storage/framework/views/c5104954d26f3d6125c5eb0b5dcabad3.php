<!doctype html>
<html lang="en">


<?php $__env->startSection('title', 'Data Kriteria'); ?>

<body>

    <div class="screen-cover d-none d-xl-none"></div>

    <div class="row">
        <div class="col-12 col-lg-3 col-navbar d-none d-xl-block">
            <?php echo $__env->make('layouts.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>


        <div class="col-12 col-xl-9">
            <?php echo $__env->make('layouts.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

            <div class="content">
                <div class="row">
                    <div class="col-12">
                        <h2 class="content-title">Data Kriteria</h2>
                    </div>

                    <div class="statistics-card">
                        <a href="<?php echo e(route('tambah-data-kriteria')); ?>" class="btn btn-primary btn-sm">Tambah Data</a>
                        <table class="table table-striped table-sm table-hover mt-2">
                            <thead>
                                <tr>
                                    <th>No</th>
                                    <th>Aspek</th>
                                    <th>Nama Kriteria</th>
                                    <th>Nilai Standar</th>
                                    <th>Faktor</th>
                                    <th>Persentase</th>
                                    <th>Aksi</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__empty_1 = true; $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                    <tr>
                                        <td><?php echo e(++$key); ?></td>
                                        <td><?php echo e($item->aspek); ?></td>
                                        <td><?php echo e($item->nama_kriteria); ?></td>
                                        <td><?php echo e($item->nilai_standar); ?></td>
                                        <td><?php echo e($item->faktor); ?></td>
                                        <td><?php echo e($item->persentase); ?></td>
                                        <td>
                                            <a href="<?php echo e(route('edit-data-kriteria', $item->id)); ?>" class="btn btn-secondary btn-sm">
                                                Ubah
                                            </a>
                                        </td>
                                        <td>
                                            <a href="<?php echo e(route('hapus-data-kriteria', $item->id)); ?>" class="btn btn-danger btn-sm" onclick="return confirm('Hapus?')">
                                                Hapus
                                            </a>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                    <tr>
                                        <td colspan="6" class="text-center">Belum ada data</td>
                                    </tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>

            </div>
        </div>
    </div>




    <?php echo $__env->make('includes.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <script>
        const navbar = document.querySelector('.col-navbar')
        const cover = document.querySelector('.screen-cover')

        const sidebar_items = document.querySelectorAll('.sidebar-item')

        function toggleNavbar() {
            navbar.classList.toggle('d-none')
            cover.classList.toggle('d-none')
        }

        function toggleActive(e) {
            sidebar_items.forEach(function(v, k) {
                v.classList.remove('active')
            })
            e.closest('.sidebar-item').classList.add('active')

        }
    </script>
</body>

</html>

<?php echo $__env->make('includes.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Luthfi\Skripsi\Vira\App\vira_kartika_profil_matching\resources\views\data-kriteria.blade.php ENDPATH**/ ?>