<!doctype html>
<html lang="en">
<?php echo $__env->make('includes.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->startSection('title', 'Laporan'); ?>

<body>
    <div class="container">
        <div class="card mt-5">
            <div class="card-header text-center">
                <h3><u>Laporan Hasil Perhitungan Profil Matching</u></h3>
                <h5><?php echo e($data->subjek); ?></h5>
            </div>
            <div class="card-body">
                <table class="table table-bordered">
                    <thead>
                        <tr>
                            <th>No.</th>
                            <th>Nama</th>
                            <th>Nilai Akhir</th>
                            <th>Ranking</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                            $count = 0;
                        ?>
                        <?php $__currentLoopData = $datas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e(++$key); ?></td>
                                <td><?php echo e($item->nama); ?></td>
                                <td><?php echo e($item->nilai); ?></td>

                                <td><?php echo e(++$count); ?></td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

</body>

</html>
<?php /**PATH D:\Luthfi\Skripsi\Vira\App\vira_kartika_profil_matching\resources\views\cetak-laporan.blade.php ENDPATH**/ ?>